from django.shortcuts import render
from django.http import HttpResponse
from pyzbar.pyzbar import decode
from PIL import Image
import os
from django.core.files.storage import default_storage
from .blockchain import verify_product  # 👈 Import your blockchain logic

def qr_scan(request):
    return render(request, 'verifier/qr_scan.html')

def verify_qr(request):
    if request.method == 'POST':
        image_file = request.FILES['qr_image']
        file_path = default_storage.save(image_file.name, image_file)
        image = Image.open(file_path)

        decoded_objs = decode(image)
        os.remove(file_path)

        if not decoded_objs:
            return HttpResponse("No QR code found in the image.")

        qr_data = decoded_objs[0].data.decode('utf-8')

        # Call blockchain verification
        product = verify_product(qr_data)

        if product:
            if product['verified']:
                return HttpResponse(f"✅ Verified Product: {product['product_name']}")
            else:
                return HttpResponse(f"❌ Counterfeit Detected: {product['product_name']}")
        else:
            return HttpResponse("❌ QR Code not recognized in blockchain.")
