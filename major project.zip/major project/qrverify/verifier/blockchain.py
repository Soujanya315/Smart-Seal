# Mock Blockchain Ledger
blockchain = {
    "ABC123": {"product_name": "Nike Shoes", "verified": True},
    "XYZ456": {"product_name": "Adidas T-shirt", "verified": True},
    "FAKE000": {"product_name": "Counterfeit Item", "verified": False}
}

# Function to verify product using QR data
def verify_product(qr_data):
    """
    Simulates checking the blockchain ledger for the product.
    Returns product details if found, else None.
    """
    return blockchain.get(qr_data, None)
