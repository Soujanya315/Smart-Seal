from django.urls import path
from . import views

urlpatterns = [
    path('qr_scan/', views.qr_scan, name='qr_scan'),
    path('verify_qr/', views.verify_qr, name='verify_qr'),
    path('generate_qr/', views.generate_qr, name='generate_qr'),
]
