from django.db import models

class Product(models.Model):
    product_name = models.CharField(max_length=255)
    qr_code = models.CharField(max_length=255, unique=True)
    verified = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.product_name} - {self.qr_code}"
